sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("ust.clogproject1.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map